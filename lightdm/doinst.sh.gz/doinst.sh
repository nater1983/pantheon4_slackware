config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
    rm $NEW
  fi
}

preserve_perms() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  if [ -e $OLD ]; then
    cp -a $OLD ${NEW}.incoming
    cat $NEW > ${NEW}.incoming
    mv ${NEW}.incoming $NEW
  fi
  config $NEW
}

preserve_perms etc/rc.d/rc.4.local.new
config etc/keys.conf.new
config etc/lightdm.conf.new
config etc/users.conf.new

# creating lightdm group if he isn't already there
if ! getent group lightdm >/dev/null; then
        addgroup --system lightdm
fi

# creating lightdm user if he isn't already there
if ! getent passwd lightdm >/dev/null; then
        adduser --system --ingroup lightdm --home /var/lib/lightdm lightdm
        usermod -c "Light Display Manager" lightdm
        usermod -d "/var/lib/lightdm"      lightdm
        usermod -g "lightdm"               lightdm
        usermod -s "/bin/false"            lightdm
fi
